import Button from  './../Buttons/Buttons';

const ListItem = ( {tasks} ) => {
  const tasksExist = tasks.length > 0;

  if ( !tasksExist) {
    return (
      <li className="todo-item justify-content-center">
        <span className="todo-item-text">Список дел пуст</span>
      </li>
    );
  };
  
  return tasks.map( (el) => (
    <li key={el.id} className="todo-item">
      <span className="todo-item-text">{el.title}</span>
      <div className="btn-group">
        <Button classNames = 'btn-outline-dark btn-sm'  text= 'Важное' />
        <Button classNames = 'btn-outline-danger btn-sm'  text= 'Удалить' />
      </div>
    </li>
	));
}

export default ListItem;