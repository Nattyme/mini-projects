import './style.css';

const Title = ({title}) => {
  return (
    <div className="admin-heading-1">{title}</div>
  );
}
 
export default Title;