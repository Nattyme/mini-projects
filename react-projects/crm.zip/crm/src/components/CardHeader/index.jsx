const CardHeader = ({text}) => {
  return (
    <div className="card-header">{text}</div>
  );
}
 
export default CardHeader;