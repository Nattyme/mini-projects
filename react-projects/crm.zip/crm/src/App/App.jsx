import { Routes, Route, useLocation } from "react-router-dom";
import { createContext } from "react";

import useAppState from "../hooks/useAppState";
import { useBodyClass } from "../hooks/useBodyClass";
import {sendNewFormData} from "./../utils/taskUtils";
import FormPage from "../pages/FormPage";
import HeaderNav from "../components/HeaderNav";
import TablePage from "../pages/Table";
import EditPage from "../pages/Edit";
import Loader from "../components/Loader";
import "./style.css";

export const AppContext = createContext(null);


const App = () => {
  const location = useLocation();
  useBodyClass(location.pathname); // Установим класс для body в зав-ти от текущей страницы
  const { appState, setAppState } = useAppState();

  return (
    <div className="App">
      {/* Навигация */}
      <HeaderNav />

      {/* Глобальный контекст приложения */}
      <AppContext.Provider
        value={{
          appState,
          setAppState,
          sendNewFormData,
        }}
      >


        {/* ===== ROUTER =====*/}
        {appState.loading ? (
          <Loader />
        ) : (
          <Routes>
            {/* Главная страница с формой */}
            <Route
              path="/"
              element={
                appState.formData &&
                appState.products &&
                appState.pages && <FormPage />
              }
            ></Route>

            {/* Страница со списком задач */}
            <Route
              path="/tasks"
              element={
                appState.products &&
                appState.users &&
                appState.pages && <TablePage />
              }
            ></Route>

            {/* Страница редактирования задачи */}
            <Route
              path="/edit/:id"
              element={
                appState.products &&
                appState.users &&
                appState.pages && <EditPage />
              }
            ></Route>
          </Routes>
        )}
        {/* ===== ROUTER =====*/}

        

      </AppContext.Provider>
    </div>
  );
};


export default App;
