import Question from './question.js';
import Result from './result.js';

/*********************************************************************************************************** */
/*********************************************************************************************************** 
 * Модуль для викторины и достижения.
 * @module model
 */


//  const model = {
//   score: 0,
  
//   /**
//    * Список достижений и их значений.
//    * @type {Array<Object>}
//    */
//   achieveValues: [
//     /**
//      * Описание достижения "Мудрость".
//      * @type {Object}
//      */
//     {
//       name: 'wisdom', value: 0,
//       check: function() { return this.value > 0 && !model.achieveValues.find(item => item.name === 'uncorrectAnswers').value; },
//       increment: function() { return ++this.value; },
//       reset: function() { this.value = 0; }
//     },
//     /**
//      * Описание достижения "Некорректные ответы".
//      * @type {Object}
//      */
//     {
//       name: 'uncorrectAnswers', value: 0,
//       check: function() { return this.value > 0; },
//       increment: function() { return ++this.value; },
//       reset: function() { this.value = 0; }
//     },
//     /**
//      * Описание достижения "Комбо".
//      * @type {Object}
//      */
//     {
//       name: 'combo', value: 0,
//       check: function() { return this.value > 1 ? this.value : false; },
//       increment: function() { return ++this.value; },
//       reset: function() { this.value = 0; }
//     },
//     /**
//      * Описание достижения "Пропущенные ответы".
//      * @type {Object}
//      */
//     {
//       name: 'skipped', value: 0,
//       check: function() { return this.value > 0 && !model.achieveValues.find(item => item.name === 'uncorrectAnswers').value; },
//       increment: function() { return ++this.value; },
//       reset: function() { this.value = 0; }
//     }
//   ],

//   /**
//    * Массив вопросов викторины.
//    * @type {Array<Object>}
//    */
//   dataQuiz: [
//     { id: 1, question: 'Вопрос 1', answer: 'Ответ 1', options: ['Опция 1', 'Опция 2', 'Опция 3'] },
//     { id: 2, question: 'Вопрос 2', answer: 'Ответ 2', options: ['Опция 1', 'Опция 2', 'Опция 3'] }
//   ],

//   /**
//    * Управление достижениями.
//    * @namespace handlingAchieve
//    */
//   handlingAchieve: {
//     /**
//      * Проверка достижения.
//      * @param {string} achieveName - Имя достижения.
//      * @returns {boolean} - Результат проверки.
//      */
//     checkAchieve: function(achieveName) {
//       const achieve = model.achieveValues.find(item => item.name === achieveName);
//       return achieve ? achieve.check() : false;
//     },

//     /**
//      * Сброс достижений.
//      * @param {Array<string>} names - Массив имен достижений для сброса.
//      */
//     resetAchieve: function(names) { names.forEach(name => model.achieveValues.find(item => item.name === name)?.reset()); },

//     /**
//      * Увеличение достижений.
//      * @param {Array<string>} names - Массив имен достижений для увеличения.
//      */
//     increaseAchieve: function(names) { names.forEach(name => model.achieveValues.find(item => item.name === name)?.increment()); }
//   },

//   /**
//    * Генерация случайного вопроса.
//    * @param {Array<Object>} questions - Массив вопросов для выбора.
//    * @returns {Question} - Экземпляр вопроса.
//    */
//   randomizeQuestion: function(questions) {
//     let prevIndex = -1;
//     return new Question(questions[Math.floor(Math.random() * questions.length)]);
//   },

//   /**
//    * Проверка перезагрузки страницы.
//    * @returns {boolean} - Истина, если страница перезагружена.
//    */
//   watchPageReload: function() {
//     return window.performance.getEntriesByType('navigation')[0].type === 'reload';
//   }
// };
/************************************************************************************************************/
/*********************************************************************************************************** */

/****  Модуль викторины  ****/
const model = {
  score : 0,
  Question : Question,
  Result: Result,
  achieveValues : [
    {
      name : 'wisdom',
      value : 0,
      check : function () {
        let uncorrectAnswers = model.achieveValues.find(item => item.name === 'uncorrectAnswers');
        let skippedAnswers = model.achieveValues.find(item => item.name === 'skipped');
        return uncorrectAnswers.value > 0 || skippedAnswers.value > 0 || this.value === 0 ? false : true;
      },
      increment : function () {
        this.value = this.value + 1;
      },
      reset : function () {
        this.value = 0;
      }
    },
    {
      name : 'uncorrectAnswers',
      value : 0,
      check : function () {
        if (this.value > 0) {
          return true;
        }
      },
      increment : function () {
       this.value = this.value + 1;
      },
      reset : function () {
        this.value = 0;
      }
    },
    {
      name : 'combo',
      value : 0,
      check : function () {
        return this.value > 1 ? this.value : false;
      },
      increment : function () {
        this.value = this.value + 1;
      },
      reset : function () {
        this.value = 0;
      }
    },
    {
      name : 'skipped',
      value : 0,
      check : function () {
        let uncorrectAnswers = model.achieveValues.find(item => item.name === 'uncorrectAnswers');
        let wisdom = model.achieveValues.find(item => item.name === 'wisdom');
        if (this.value > 0 && wisdom.value === 0 && uncorrectAnswers.value === 0) {
          return true;
        }
      },
      increment : function () {
        this.value = this.value + 1;
      },
      reset : function () {
        this.value = 0;
      }
    }
  ],
  handlingAchieve : {
    checkAchieve : function (acheiveName) {
      let currentAcheiveObj = model.achieveValues.find(item => item.name === acheiveName); 
      
      if (!currentAcheiveObj) {
        return false;
      }
      return currentAcheiveObj.check() ? currentAcheiveObj.check() : false;
    },
    resetAchieve : function (achievesArray) {
      achievesArray.forEach(achieveName => {
        const currentAcheiveObj = model.achieveValues.find(item => item.name === achieveName);
        if (currentAcheiveObj) {
          currentAcheiveObj.reset();
        };
      });
    },
    increaseAchieve : function (achievesArray) {
 
      achievesArray.forEach(achieveName => {
        const currentAcheiveObj = model.achieveValues.find(item => item.name === achieveName);
     
        if (currentAcheiveObj) { 
          currentAcheiveObj.increment();
        }
      });

      return;
    }, 
  },
  randomizeQuestion : function (questionArray) {
    let randomQuestionObj = {};
    let question = {};
    let questionQuantity = questionArray.length;
    
    let prevIndex = 0;  // Храним индекс предыдущего вопроса

    const randomizer = function () {
      return Math.floor(Math.random() * questionQuantity);
    };

    const checkRepeat = function () {
      let randomIndex = randomizer();

      // Если случ. индекс совпадает с предыдущим, создаём новый индекс
      while (randomIndex === prevIndex) {
        randomIndex = randomizer();
      }

      // Перезапишем предыдущий индекс
      prevIndex = randomIndex;

      return randomIndex;
    };

    // Вызываем функцию, чтобы получить случайный индекс
    const randomIndex = checkRepeat();

    randomQuestionObj = questionArray[randomIndex];

    // Создадим объект вопроса
    question =  new Question( randomQuestionObj.question, randomQuestionObj.answer, randomQuestionObj.options);
    return question;
  },
  watchPageReload : function () {
    if (window.performance.getEntriesByType('navigation')[0].type === 'reload') {
      return true;
    } 
  }
}

export default model;